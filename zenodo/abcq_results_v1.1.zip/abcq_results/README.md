# ABC-Q: raw experimental results (version 1.1)

Raw per-run results for the paper
**"Surrogate-Assisted Discrete Artificial Bee Colony Search for Budget-Constrained
Mixed-Precision Post-Training Quantization"** (Manav, Sarthak Jain, Manik Dhiman, Shreshth Varshney;
Netaji Subhas University of Technology, Delhi).

Dataset DOI: https://doi.org/10.5281/zenodo.24276626

Every number, table and figure in the paper can be recomputed from these files.
Version 1.1 adds the ImageNet-pretrained CNN and large-language-model experiments; the CIFAR results
are unchanged from version 1.0 (only moved into `cifar/`).

## Contents

```
abcq_results/
  README.md
  imagenet_llm_summary.csv          mean/std per (task, model, budget, method) + float/uniform references
  cifar/
    summary_by_method.csv
    <backbone>/<dataset>/            resnet20 | mobilenetv2  x  cifar10 | cifar100
      runs.jsonl  model_stats.json  qat_B250.json  float_train_log.json
  imagenet/<model>/                  mobilenetv2 | resnet18      (ImageNet-pretrained, evaluated on ImageNetV2)
      runs.jsonl  model_stats.json
  llm/<model>/                       opt125m | opt350m | qwen0.5b | llama3.2-1b
      runs.jsonl  model_stats.json
```

## Methods (`method` field)

| key | method in the paper |
|---|---|
| `random` | Random search (CIFAR only) |
| `ga` | Genetic algorithm |
| `cmaes` | CMA-ES |
| `abc_gp` | ABC-GP: discrete ABC with gradient-magnitude prior (CIFAR only) |
| `fisher_mckp` | Fisher-MCKP: HAWQ-V2-style one-shot allocation |
| `probe_mckp` | Probe-MCKP: one-shot allocation from measured probes |
| `abcq` | ABC-Q (proposed) |
| `abcq_noscreen`, `abcq_nolearn`, `abcq_noknap`, `abcq_noshare`, `abcq_hc` | CIFAR ablations: without surrogate screening / online surrogate refit / knapsack seeding / information sharing; single-source hill climber |

## CIFAR (`cifar/`)

Weights and layer inputs at the layer's bit-width b ∈ {2, 4, 8} (per-channel symmetric weights,
per-tensor min–max activations); cost = MAC-weighted BOPs relative to W8A8; budgets 0.25 and 0.35;
10 seeds; E = 300 evaluations. `runs.jsonl` fields: `budget`, `seed`, `evals_used`, `calib_acc`
(1,000-image calibration set, the search objective), `test_acc` (10,000 test images, no fine-tuning),
`bops`, `mem`, `avg_bits_param`, `config` (per-layer bits), `trace` (best feasible calibration accuracy
every 5 evaluations), `wall_s`. `qat_B250.json`: test accuracy before/after 2 epochs of QAT.

## ImageNet (`imagenet/`)

ImageNet-pretrained MobileNetV2 and ResNet-18; ImageNetV2 matched-frequency split into 512 calibration
and 9,488 test images. Weights mixed in {2, 4, 8} bits, activations fixed at 8 bits (W{2,4,8}A8);
cost = 8·b·MACs relative to W8A8. Budgets: MobileNetV2 0.6, ResNet-18 0.5 (= uniform W4A8), plus a
budget sweep for the one-shot methods. 3 seeds; E = 300.
`runs.jsonl`: `calib_score` = calibration top-1 accuracy, `test` = test top-1 accuracy, `cost`.

## LLMs (`llm/`)

OPT-125M, OPT-350M, Qwen2.5-0.5B, Llama-3.2-1B. Weight-only group-wise (128) round-to-nearest
quantization of every linear layer in the transformer blocks, b ∈ {2, 3, 4}; cost = bits per parameter
relative to 4 bits (budget 0.75 = 3.0 bits/parameter). 3 seeds; E = 2L + 201.
`runs.jsonl`: `calib_score` = −(mean negative log-likelihood) on 8 × 512 WikiText-2 training tokens
(higher is better), `test` = WikiText-2 perplexity on the first 65,536 test tokens (context 512; lower is
better), `cost`.

## `model_stats.json` (all tasks)

Layer names and sizes, float and uniform-precision references (`float_*`, `uniform<b>`), measured
single-layer probes (`delta`, L × |bits|; CIFAR also `acc8`, ImageNet/LLM `score_top`), the
gradient-magnitude prior (`grad_prior`), empirical-Fisher traces (`fisher_trace`) and squared weight
quantization errors (`weight_qerr`).

## Software and hardware

CIFAR: TensorFlow 2.16. ImageNet/LLM: PyTorch 2.15 + Hugging Face Transformers. All runs on one Apple M4
laptop (16 GB). Pretrained checkpoints are the public Hugging Face releases (google/mobilenet_v2_1.0_224,
microsoft/resnet-18, facebook/opt-125m, facebook/opt-350m, Qwen/Qwen2.5-0.5B, meta-llama/Llama-3.2-1B).

## License

CC BY 4.0. Please cite the paper and this dataset if you use these results.
